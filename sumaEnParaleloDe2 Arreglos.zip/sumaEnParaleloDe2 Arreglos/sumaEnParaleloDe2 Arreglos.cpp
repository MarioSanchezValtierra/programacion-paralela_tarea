// sumaEnParaleloDe2 Arreglos.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>

#include <ctime>

#ifdef _OPENMP
#include <omp.h>
#else
#define omp_get_thread_num() 0
#define omp_get_num_threads() 1
#endif

#define N 1000
#define chunk 100
#define mostrar 10

void imprimeArreglo(float* d);

int main()
{
    std::cout << "Hola, soy Mario Sanchez Valtierra; esta es la primera ejecucion del ejercicio.!\n";

    time_t ahora = time(nullptr);
    char buffer[26];   // tamaño requerido por ctime_s

    ctime_s(buffer, sizeof(buffer), &ahora);

    std::cout << "Hora actual: " << buffer;

    // Configuración explícita de OpenMP
    omp_set_dynamic(0);
    
    // Le desimos a la maquina que calcule el numero de hilos maximo.
    int hilos = omp_get_num_procs();
    omp_set_num_threads(hilos);

    std::cout << "Sumando Arreglos en Paralelo!\n";

    float a[N], b[N], c[N];
    int i;

    // Inicialización (secuencial)
    for (i = 0; i < N; i++)
    {
        a[i] = i * 10;
        b[i] = (i + 3) * 3.7;
    }

    int pedazos = chunk;

    // Región paralela SOLO para confirmar hilos
#pragma omp parallel
    {
#pragma omp single
        {
            std::cout << ">>> Ejecutando en paralelo con "
                << omp_get_num_threads()
                << " hilos." << std::endl;
        }
    }

    // Bucle realmente paralelo
#pragma omp parallel for schedule(static, pedazos)
    for (i = 0; i < N; i++)
    {
        c[i] = a[i] + b[i];
    }

    // Impresión
    std::cout << "Imprimiendo los primeros " << mostrar
        << " valores del arreglo a:\n";
    imprimeArreglo(a);

    std::cout << "Imprimiendo los primeros " << mostrar
        << " valores del arreglo b:\n";
    imprimeArreglo(b);

    std::cout << "Imprimiendo los primeros " << mostrar
        << " valores del arreglo c:\n";
    imprimeArreglo(c);

    return 0;
}

void imprimeArreglo(float* d)
{
    for (int x = 0; x < mostrar; x++)
        std::cout << d[x] << " - ";

    std::cout << std::endl;
}


// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

// Sugerencias para primeros pasos: 1. Use la ventana del Explorador de soluciones para agregar y administrar archivos
//   2. Use la ventana de Team Explorer para conectar con el control de código fuente
//   3. Use la ventana de salida para ver la salida de compilación y otros mensajes
//   4. Use la ventana Lista de errores para ver los errores
//   5. Vaya a Proyecto > Agregar nuevo elemento para crear nuevos archivos de código, o a Proyecto > Agregar elemento existente para agregar archivos de código existentes al proyecto
//   6. En el futuro, para volver a abrir este proyecto, vaya a Archivo > Abrir > Proyecto y seleccione el archivo .sln
